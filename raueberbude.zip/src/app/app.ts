
import {Component} from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {AuthService} from './services/auth.service';
import {ConfigService} from './services/config-service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
      <router-outlet></router-outlet>`,

  providers: [
    {
      provide: 'root',
      useFactory: (config: ConfigService) => () => config.load(),
      deps: [ConfigService],
      multi: true
    }
  ]
})
export class AppComponent {
  constructor(public auth: AuthService) {}
}


# Räuberbude Development Guidelines

Auto-generated from all feature plans. Last updated: 2025-10-16

## Active Technologies
- Angular 20
- WebSocket (Kommunikation)
- MongoDB (Datenhaltung)
- Home Assistant API
- TypeScript / JavaScript

## Project Structure
/src
/app
/services
/components
/assets
/specifications
specification.md
/agents
agent.md
roles.md


## Commands
- `specify plan` — Erzeuge eine detaillierte Umsetzung basierend auf `specification.md`.
- `specify implement` — Erstelle Code und Integrationen gemäß der Spezifikation.
- `specify test` — Erstelle automatische Tests für die Module.
- `specify review` — Prüfe Codequalität und Übereinstimmung.

## Code Style
- Angular mit TypeScript: Einhaltung des Angular Styleguides.
- Linting mit TSLint oder ESLint aktiviert.
- Saubere, dokumentierte Funktionen.
- Modularer Aufbau, klare Trennung von Komponenten, Services und Logik.
- Tests: Jest oder Angular Testing Library, 80%+ Coverage.

## Recent Changes
- **Feature 001 – Geräteverwaltung**: MongoDB, Nutzer und Geräte verwaltet, API für Gerätesteuerung.
- **Feature 002 – Lichtsteuerung**: WebSocket Steuerung für Raum-Lights hinzugefügt.
- **Feature 003 – Nutzerrollen**: Rollen- und Rechteverwaltung für Nutzer implementiert.

<!-- MANUAL ADDITIONS START -->
<!-- Hier kannst du weitere Anweisungen für den Agenten ergänzen, z. B. Arbeitsabläufe, spezielle Regeln, etc. -->
<!-- MANUAL ADDITIONS END -->
